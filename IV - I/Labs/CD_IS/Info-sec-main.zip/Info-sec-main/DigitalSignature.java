import java.security.*;

public class DigitalSignature {

    public static void main(String[] args) throws Exception {
        // 1. Generate Key Pair
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA"); // Or "DSA"
        keyGen.initialize(1024); // Key size
        KeyPair keyPair = keyGen.generateKeyPair();
        PrivateKey privateKey = keyPair.getPrivate();
        PublicKey publicKey = keyPair.getPublic();

        // 2. Data to be signed
        byte[] data = "This is a message to be digitally signed.".getBytes();

        // 3. Sign the data
        Signature signature = Signature.getInstance("MD5withRSA"); // Or "SHA256withRSA"
        signature.initSign(privateKey);
        signature.update(data);
        byte[] digitalSignature = signature.sign();

        System.out.println("Digital Signature created.");

        // 4. Verify the signature
        Signature verifier = Signature.getInstance("MD5withRSA"); // Must match signing algorithm
        verifier.initVerify(publicKey);
        verifier.update(data);
        boolean verified = verifier.verify(digitalSignature);

        System.out.println("Signature Verified: " + verified);
    }
}