import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;

public class SHADemo {

    public static String generateSHA256Hash(String input) {
        try {
            // Get an instance of the SHA-256 MessageDigest algorithm
            MessageDigest md = MessageDigest.getInstance("SHA-256");

            // Convert the input string to bytes
            byte[] messageDigest = md.digest(input.getBytes());

            // Convert the byte array to a hexadecimal string
            StringBuilder hexString = new StringBuilder();
            for (byte b : messageDigest) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            return hexString.toString();

        } catch (NoSuchAlgorithmException e) {
            // Handle the case where the algorithm is not available
            throw new RuntimeException("SHA-256 algorithm not found", e);
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a String: ");
        String originalString = sc.nextLine();
        String sha256Hash = generateSHA256Hash(originalString);
        System.out.println("Original String: " + originalString);
        System.out.println("SHA-256 Hash: " + sha256Hash);

        System.out.print("Enter a String with little variation: ");
        String anotherString = sc.nextLine(); // Slightly different
        String sha256Hash2 = generateSHA256Hash(anotherString);
        System.out.println("Another String: " + anotherString);
        System.out.println("SHA-256 Hash: " + sha256Hash2);
        sc.close();
    }
}