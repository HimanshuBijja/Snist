import java.security.*;
import javax.crypto.*;
import java.util.Base64; // Import Base64 utility
import java.util.Scanner;

public class DES {
    public static void main(String args[]) {
        try {
            // Explicitly specify Mode and Padding for consistency
            Cipher desCipher = Cipher.getInstance("DES/ECB/PKCS5Padding");
            
            KeyGenerator keygen = KeyGenerator.getInstance("DES");
            SecureRandom randomSeed = new SecureRandom();
            keygen.init(randomSeed);
            Key deskey = keygen.generateKey();

            // --- Encryption ---
            int mode = Cipher.ENCRYPT_MODE;
            desCipher.init(mode, deskey);
            
            Scanner console = new Scanner(System.in);
            System.out.println("Enter a text for encryption");
            String plainText = console.nextLine();

            // The crypt method now returns Base64-encoded String (safe for transport/printing)
            String encryptedText = crypt(desCipher, plainText, Cipher.ENCRYPT_MODE);
            System.out.println("The encrypted text is " + encryptedText);

            // --- Decryption ---
            mode = Cipher.DECRYPT_MODE;
            desCipher.init(mode, deskey);
            
            // The crypt method is used for decryption, taking the Base64 String
            String decryptedText = crypt(desCipher, encryptedText, Cipher.DECRYPT_MODE);
            System.out.println("The decrypted text is " + decryptedText);
            
        } catch(GeneralSecurityException e) {
            System.out.println("Security Exception: " + e.getMessage());
        }
    }
    
    // The crypt method now handles ENCRYPT and DECRYPT modes separately and uses Base64
    public static String crypt(Cipher desCipher, String in, int mode) throws GeneralSecurityException {
        if (mode == Cipher.ENCRYPT_MODE) {
            // 1. Convert input String to bytes (using standard UTF-8 is often best)
            byte[] inBytes = in.getBytes(java.nio.charset.StandardCharsets.UTF_8);

            // 2. Encrypt the data
            byte[] outBytes = desCipher.doFinal(inBytes);
            
            // 3. Convert binary ciphertext to a safe text representation (Base64)
            return Base64.getEncoder().encodeToString(outBytes);
        
        } else if (mode == Cipher.DECRYPT_MODE) {
            // 1. Convert Base64 String back to binary ciphertext bytes
            byte[] inBytes = Base64.getDecoder().decode(in);
            
            // 2. Decrypt the data
            byte[] outBytes = desCipher.doFinal(inBytes);
            
            // 3. Convert the resulting plaintext bytes back to the original String
            return new String(outBytes, java.nio.charset.StandardCharsets.UTF_8);
            
        } else {
            throw new IllegalArgumentException("Invalid cipher mode specified.");
        }
    }
}