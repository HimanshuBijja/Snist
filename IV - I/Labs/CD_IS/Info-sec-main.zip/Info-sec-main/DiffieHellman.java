// Source: Gemini
import java.math.BigInteger;
import java.util.Random;

public class DiffieHellman {

    public static void main(String[] args) {
        // --- 1. Publicly agreed-upon large numbers ---

        // p: A large prime number (modulus). Must be agreed upon publicly.
        // G: A primitive root modulo p (base). Must be agreed upon publicly.
        // For security, these should be generated dynamically and much larger.
        // We use small numbers here for demonstration and easy verification.
        BigInteger P = new BigInteger("23"); // Prime P
        BigInteger G = new BigInteger("5");  // Base G (Primitive Root)

        System.out.println("--- Public Parameters ---");
        System.out.println("Prime P: " + P);
        System.out.println("Base G: " + G);


        // --- 2. Private Key Generation ---

        // Alice's private key 'a'
        BigInteger a = new BigInteger("6"); // a < P-1 (a random secret)
        // Bob's private key 'b'
        BigInteger b = new BigInteger("15"); // b < P-1 (a random secret)

        System.out.println("\n--- Private Secrets ---");
        System.out.println("Alice's Private Key (a): " + a);
        System.out.println("Bob's Private Key (b): " + b);
        System.out.println("-------------------------\n");

        // --- 3. Public Key Calculation (Exchange) ---

        // Alice computes her Public Key (A): A = G^a mod P
        BigInteger A = G.modPow(a, P);
        
        // Bob computes his Public Key (B): B = G^b mod P
        BigInteger B = G.modPow(b, P);
        
        System.out.println("--- Public Values Exchanged ---");
        System.out.println("Alice's Public Key (A) sent to Bob: " + A);
        System.out.println("Bob's Public Key (B) sent to Alice: " + B);

        // --- 4. Shared Secret Key Generation ---

        // Alice computes the Shared Secret Key (K_A): K_A = B^a mod P
        BigInteger K_A = B.modPow(a, P);
        
        // Bob computes the Shared Secret Key (K_B): K_B = A^b mod P
        BigInteger K_B = A.modPow(b, P);

        // Verification: K_A must equal K_B
        System.out.println("\n--- Shared Secret Key Calculation ---");
        System.out.println("Alice's Shared Secret (K_A = B^a mod P): " + K_A);
        System.out.println("Bob's Shared Secret (K_B = A^b mod P): " + K_B);

        if (K_A.equals(K_B)) {
            System.out.println("\nSuccess! Shared secret keys match.");
            System.out.println("Final Shared Symmetric Key: " + K_A);
        } else {
            System.out.println("\nError! Shared secret keys do not match.");
        }
    }
}