import java.util.Arrays;
import java.util.Scanner;

public class RowTranspositionCipher {

    // Helper method to get the sorted order of the key
    private static int[] getKeyOrder(String key) {
        char[] keyChars = key.toCharArray();
        int[] keyOrder = new int[key.length()];
        Character[] sortedKeyChars = new Character[key.length()];

        for (int i = 0; i < key.length(); i++) {
            sortedKeyChars[i] = keyChars[i];
        }
        Arrays.sort(sortedKeyChars);

        for (int i = 0; i < key.length(); i++) {
            for (int j = 0; j < key.length(); j++) {
                if (keyChars[i] == sortedKeyChars[j]) {
                    keyOrder[i] = j; // Store the original index's position in the sorted key
                    sortedKeyChars[j] = 0; // Mark as used
                    break;
                }
            }
        }
        return keyOrder;
    }

    public static String encrypt(String plaintext, String key) {
        int keyLength = key.length();
        int[] keyOrder = getKeyOrder(key);

        // Calculate rows needed, padding if necessary
        int numRows = (int) Math.ceil((double) plaintext.length() / keyLength);
        char[][] matrix = new char[numRows][keyLength];

        // Fill the matrix row by row
        int charIndex = 0;
        for (int i = 0; i < numRows; i++) {
            for (int j = 0; j < keyLength; j++) {
                if (charIndex < plaintext.length()) {
                    matrix[i][j] = plaintext.charAt(charIndex++);
                } else {
                    matrix[i][j] = 'X'; // Padding character
                }
            }
        }

        StringBuilder ciphertext = new StringBuilder();
        // Read the matrix column by column based on the sorted key order
        for (int k = 0; k < keyLength; k++) {
            for (int col = 0; col < keyLength; col++) {
                if (keyOrder[col] == k) { // Find the column that corresponds to the k-th sorted key char
                    for (int row = 0; row < numRows; row++) {
                        ciphertext.append(matrix[row][col]);
                    }
                    break;
                }
            }
        }
        return ciphertext.toString();
    }

    public static String decrypt(String ciphertext, String key) {
        int keyLength = key.length();
        int[] keyOrder = getKeyOrder(key);

        int numRows = (int) Math.ceil((double) ciphertext.length() / keyLength);
        char[][] matrix = new char[numRows][keyLength];

        // Fill the matrix column by column based on the sorted key order
        int charIndex = 0;
        for (int k = 0; k < keyLength; k++) {
            for (int col = 0; col < keyLength; col++) {
                if (keyOrder[col] == k) {
                    for (int row = 0; row < numRows; row++) {
                        matrix[row][col] = ciphertext.charAt(charIndex++);
                    }
                    break;
                }
            }
        }

        StringBuilder plaintext = new StringBuilder();
        // Read the matrix row by row
        for (int i = 0; i < numRows; i++) {
            for (int j = 0; j < keyLength; j++) {
                plaintext.append(matrix[i][j]);
            }
        }
        return plaintext.toString();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter plaintext: ");
        String plaintext = scanner.nextLine().toUpperCase().replaceAll("[^A-Z]", ""); // Remove non-alphabetic chars and convert to uppercase

        System.out.print("Enter key (e.g., ZEBRAS): ");
        String key = scanner.nextLine().toUpperCase().replaceAll("[^A-Z]", "");

        String encryptedText = encrypt(plaintext, key);
        System.out.println("Encrypted text: " + encryptedText);

        String decryptedText = decrypt(encryptedText, key);
        System.out.println("Decrypted text: " + decryptedText);

        scanner.close();
    }
}