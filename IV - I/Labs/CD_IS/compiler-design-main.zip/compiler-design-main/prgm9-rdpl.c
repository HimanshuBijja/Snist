#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char input[100];
int pos = 0;

// Function declarations
void S();
void L();
void Lprime();

void error() {
    printf("Syntax Error at position %d\n", pos);
    exit(1);
}

char peek() {
    return input[pos];
}

void match(char expected) {
    if (peek() == expected) {
        pos++;
    } else {
        error();
    }
}

// S → (L) | a
void S() {
    if (peek() == '(') {
        match('(');
        L();
        match(')');
    } else if (peek() == 'a') {
        match('a');
    } else {
        error();
    }
}

// L → SL'
void L() {
    S();
    Lprime();
}

// L' → ,SL' | ε
void Lprime() {
    if (peek() == ',') {
        match(',');
        S();
        Lprime();
    }
    // else ε (do nothing)
}

int main() {
    printf("Enter a string: ");
    scanf("%s", input);
    
    S();
    
    if (input[pos] == '\0') {
        printf("Parsing successful: Valid string.\n");
    } else {
        printf("Parsing failed: Extra characters after valid string.\n");
    }
    
    return 0;
}

