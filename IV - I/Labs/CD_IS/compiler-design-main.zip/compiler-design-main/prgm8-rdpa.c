#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

char input[100];
int pos = 0;

void E();
void Eprime();
void T();
void Tprime();
void F();

void error() {
    printf("\n\033[31mSyntax Error\033[0m at position %d.\n", pos);
    printf("Input: %s\n", input);
    for(int i = 0; i < pos; i++) {
        printf(" ");
    }
    printf("^\n");
    exit(1);
}

void skip_whitespace() {
    while (isspace(input[pos])) {
        pos++;
    }
}

char peek() {
    skip_whitespace();
    return input[pos];
}

void match(char expected) {
    if (peek() == expected) {
        pos++;
    } else {
        printf("Expected '%c' but found '%c'\n", expected, peek());
        error();
    }
}

void E() {
    T();
    Eprime();
}

void Eprime() {
    if (peek() == '+') {
        match('+');
        T();
        Eprime();
    }
}

void T() {
    F();
    Tprime();
}

void Tprime() {
    if (peek() == '*') {
        match('*');
        F();
        Tprime();
    }
}

void F() {
    if (peek() == '(') {
        match('(');
        E();
        match(')');
    } else if (isalpha(peek())) {
        pos++;
        while (isalnum(peek())) {
            pos++; 
        }
    } else {
        printf("Expected '(' or 'id' (identifier)\n");
        error();
    }
}

int main() {
    printf("Enter the expression: ");
    if (fgets(input, sizeof(input), stdin) == NULL) {
        fprintf(stderr, "Error reading input.\n");
        return 1;
    }
    input[strcspn(input, "\n")] = 0;
    E();
    if (input[pos] == '\0') {
        printf("\n\033[32mParsing successful:\033[0m Valid expression.\n");
    } else {
        printf("\n\033[33mParsing failed:\033[0m Extra symbols found starting at position %d.\n", pos);
        printf("Remaining input: \"%s\"\n", input + pos);
    }
    return 0;
}