#include <stdio.h>
#include <string.h>

enum State {
    q0, q1, q2, q3, q4, q5
};

State transition(State current, char symbol) {
    switch (current) {
        case q0:
            return (symbol == 'a') ? q1 : q3;           
        case q1:
            return (symbol == 'a') ? q2 : q4;            
        case q2:
            return (symbol == 'a') ? q0 : q5;            
        case q3:
            return (symbol == 'a') ? q4 : q0;            
        case q4:
            return (symbol == 'a') ? q5 : q1;            
        case q5:
            return (symbol == 'a') ? q3 : q2;            
        default:
            return q0;
    }
}

int main() {
    char input[100];
    State state = q0;
    
    printf("Enter a string over the alphabet {a, b}: ");
    scanf("%s", input);
    
    for (int i = 0; input[i] != '\0'; i++) {
        if (input[i] != 'a' && input[i] != 'b') {
            printf("Invalid input: only 'a' and 'b' are allowed.\n");
            return 1;
        }
    }
    
    for (int i = 0; input[i] != '\0'; i++) {
        state = transition(state, input[i]);
    }
    
    if (state == q0) {
        printf("Accepted: Number of a's divisible by 3 and b's divisible by 2.\n");
    } else {
        printf("Rejected: Condition not satisfied.\n");
    }    
    return 0;
}

