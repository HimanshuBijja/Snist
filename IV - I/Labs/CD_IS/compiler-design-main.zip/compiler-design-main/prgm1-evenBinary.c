#include <stdio.h>
#include <string.h>

int isEvenBinary(char *input) {
    int state = 0;     
    for (int i = 0; input[i] != '\0'; i++) {
        char symbol = input[i];        
        if (symbol != '0' && symbol != '1') {
            printf("Invalid input: Only binary digits (0 and 1) are allowed.\n");
            return 0;
        }        
        switch (state) {
            case 0: 
                if (symbol == '0') {
                    state = 0; 
                } else { 
                    state = 1; 
                }
                break;                
            case 1: 
                if (symbol == '0') {
                    state = 0; 
                } else { 
                    state = 1; 
                }
                break;
        }
    }    
    return state == 0;
}

int main() {
    char binary[100];    
    printf("Enter a binary number: ");
    scanf("%s", binary);    
    if (isEvenBinary(binary)) {
        printf("Accepted: The binary number is even.\n");
    } else {
        printf("Rejected: The binary number is odd.\n");
    }    
    return 0;
}

