#include <stdio.h>
#include <string.h>

enum State {
    q0, q1, q2, q3
};

int isAccepted(char *input) {
    State state = q0;    
    for (int i = 0; input[i] != '\0'; i++) {
        char symbol = input[i];
        if (symbol != '0' && symbol != '1') {
            printf("Invalid input: Only 0 and 1 are allowed.\n");
            return 0;
        }
        switch (state) {
            case q0:
                if (symbol == '0') {
                    state = q1;
                } else { 
                    state = q3;
                }
                break;                
            case q1:
                if (symbol == '0') {
                    state = q2;
                } else { 
                    state = q3;
                }
                break;
                
            case q2:
                if (symbol == '0') {
                    state = q2;
                } else { 
                    state = q3;
                }
                break;
                
            case q3:
                if (symbol == '0') {
                    state = q1;
                } else { 
                    state = q3;
                }
                break;
        }
    }
    return state != q2;
}

int main() {
    char input[100];
    printf("Enter a binary string (0s and 1s): ");
    scanf("%s", input);    
    if (isAccepted(input)) {
        printf("Accepted: String does NOT end with 00.\n");
    } else {
        printf("Rejected: String ends with 00.\n");
    }   
    return 0;
}

