# First check lex and yacc programs in your System. if not use below to download:
### For Ubuntu 
`sudo apt install flex bison`
```markdown
**💡 TIP:** If you Don't want to take windows process below, just use Github Codespaces to get online Ubuntu session
1. Log in to your Github
2. [open this link](https://github.com/codespaces)
3. Click Blank Template, and use your free Session to execute codes
```
### For Windows
1. First Download both setup files from below links
    1. [flex Link](https://sourceforge.net/projects/gnuwin32/files/flex/2.5.4a-1/flex-2.5.4a-1.exe/download?use_mirror=excellmedia&download)
    2. [bison Link](https://sourceforge.net/projects/gnuwin32/files/bison/2.4.1/bison-2.4.1-setup.exe/download?use_mirror=excellmedia)
2. Click on both of them to install only on root `C:\` folder (it should be `C:\GnuWin32` after installing)
3. In windows search type `edit the system environment`
    1. click Environment Variables
    2. Double Click on Path and click New
    3. Paste this in new line `C:\GnuWin32\bin`
    4. Click Apply, Ok, Ok, Ok..

<hr>

# Commands to Execute in terminal: 

### 1. For All C programs:

`gcc file_name.c`<br>
`./a` or `./a.out` or `a.exe`

### 2. For All Lex programs: (Use lex(Ubuntu), flex(Windows))

1. `lex your_lex_file_name.l`
2. `gcc lex.yy.c`
3. `./a  for ubuntu` or `a.exe for windows`


### 3. For All YACC programs: (Use yacc(Ubuntu), bison(Windows)) along with above lex program
To Run YACC Programs, we need a lex ('.l' extension) program and a yacc program ('.y' extension)<br>
Steps to run them:
1. `lex your_file_name.l` or `flex your_file_name.l`
2. `yacc your_file_name.y` or `bison your_file_name.y`
3. `gcc lex.yy.c your_file_name.tab.c`
4. `./a  for ubuntu` or `a.exe for windows`
