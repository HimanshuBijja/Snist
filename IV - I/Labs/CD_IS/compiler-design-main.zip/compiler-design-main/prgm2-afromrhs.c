#include <stdio.h>
#include <string.h>
#define MAX_LEN 100

int checkThirdFromRightIsA(char *input) {
    int len = strlen(input);    
    if (len < 3) {
        return 0; 
    }    
    return input[len - 3] == 'a';
}

int main() {
    char input[MAX_LEN];    
    printf("Enter a string over the alphabet {a, b}: ");
    scanf("%s", input);   
    for (int i = 0; input[i] != '\0'; i++) {
        if (input[i] != 'a' && input[i] != 'b') {
            printf("Invalid input: Only 'a' and 'b' are allowed.\n");
            return 0;
        }
    }   
    if (checkThirdFromRightIsA(input)) {
        printf("Accepted: 3rd symbol from right is 'a'.\n");
    } else {
        printf("Rejected: 3rd symbol from right is not 'a'.\n");
    }   
    return 0;
}

