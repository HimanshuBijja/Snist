#include <stdio.h>
#include <ctype.h>
#include <string.h>

// Define token types (example)
#define KEYWORD 1
#define IDENTIFIER 2
#define INTEGER_LITERAL 3
#define OPERATOR 4
#define DELIMITER 5
#define EOI 6 // End of Input

// Function to check if a string is a keyword
int isKeyword(char *str) {
    char *keywords[] = {"int", "if", "else", "while", "return"};
    for (int i = 0; i < sizeof(keywords) / sizeof(char *); i++) {
        if (strcmp(str, keywords[i]) == 0) {
            return 1;
        }
    }
    return 0;
}

// Simple lexical analyzer function
int getNextToken() {
    char c;
    char lexeme[100]; // Buffer to store the current lexeme
    int i = 0;

    // Skip whitespace
    while (isspace(c = getchar()));

    if (c == EOF) return EOI;

    // Handle identifiers and keywords
    if (isalpha(c) || c == '_') {
        lexeme[i++] = c;
        while (isalnum(c = getchar()) || c == '_') {
            lexeme[i++] = c;
        }
        ungetc(c, stdin); // Put back the non-alphanumeric character
        lexeme[i] = '\0';

        if (isKeyword(lexeme)) {
            printf("Token: Keyword, Lexeme: %s\n", lexeme);
            return KEYWORD;
        } else {
            printf("Token: Identifier, Lexeme: %s\n", lexeme);
            return IDENTIFIER;
        }
    }
    // Handle integer literals
    else if (isdigit(c)) {
        lexeme[i++] = c;
        while (isdigit(c = getchar())) {
            lexeme[i++] = c;
        }
        ungetc(c, stdin);
        lexeme[i] = '\0';
        printf("Token: Integer Literal, Lexeme: %s\n", lexeme);
        return INTEGER_LITERAL;
    }
    // Handle operators and delimiters (simplified)
    else if (c == '+' || c == '-' || c == '*' || c == '=' || c == ';') {
        lexeme[0] = c;
        lexeme[1] = '\0';
        if (c == ';') {
            printf("Token: Delimiter, Lexeme: %s\n", lexeme);
            return DELIMITER;
        } else {
            printf("Token: Operator, Lexeme: %s\n", lexeme);
            return OPERATOR;
        }
    }
    // ... handle other token types and errors
    else {
        printf("Error: Unrecognized character '%c'\n", c);
        return -1; // Indicate error
    }
}

int main() {
    printf("Enter C code (end with Ctrl+D or Ctrl+Z):\n");
    int token;
    while ((token = getNextToken()) != EOI && token != -1);
    return 0;
}
