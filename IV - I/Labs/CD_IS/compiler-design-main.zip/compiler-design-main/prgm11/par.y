%{
#include <stdio.h>
#include <stdlib.h>
extern int yylex(void);
void yyerror(const char *msg);
%}

%token ID LPAREN RPAREN COMMA

%%
S: LPAREN L RPAREN
| ID ;

L: S L1
;

L1: COMMA S L1
|
;
%%

int main() {
    printf("Enter input string:\n");
    return yyparse();
}

void yyerror(const char *msg) {
    fprintf(stderr, "Parse error: %s\n", msg);
}